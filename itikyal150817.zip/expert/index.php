<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-1965085549465896",
    enable_page_level_ads: true
  });
</script>
<script src="Js/poll.js">
</script>
<script src="Js/welcome.js">
</script><meta name="verification" content="f552de7d8d45ba87c37fe023dacefff7" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>itikyal</title>
<meta name="keywords" content="Famous Itikyal tourist place for Sai baba Temple" />
<meta name="description" content="Iikyal village development website day by date update imformation of village improment and The histroy in past year and also much more  detail about itikyal village" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>
</head>
<body> 
<?php include_once("analyticstracking.php") ?>
<?php include( "header.php" )  ; ?>
   <div id="templatemo_content_wrapper">
       <div id="templatemo_content">
    
       <div class="column_w210 fl">
        
           <div class="header_01">
               Latest Blog Posts
            </div>
            
         <div class="latest_news">
              <div class="header_03">[29-OCT-2024]</div>
               <div class="header_02"><a href="#">Aenean a bibendum augue</a></div>
                
                <p>Praesent eu ligula quis nibh ullamcorper tempor non ultrices lacus.</p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[28-OCT-2024]</div>
              <div class="header_02"><a href="#">Nulla pharetra leo eget </a></div>
                <p>Vivamus condimentum justo id tortor rhoncus eu ornare sem malesuada. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[27-OCT-2024]</div>
              <div class="header_02"><a href="#">Vivamus metus justo</a></div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="rc_btn_01"><a href="#">Read All</a></div>
            
        
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="column_w430 fl vl_divider">
           
            <img src="images/templatemo_image_01.jpg" alt="image" />
            
            <div class="header_01">Welcome to our Itikyal Village site!</div>
            
            <p>Itikial also known as itikyala is a small town in <a href="http://en.m.wikipedia.org/wiki/Karimnagar_district">Karimnagar district,</a>of<a href="http://en.m.wikipedia.org/wiki/Telangana">Telangana,</a> India. The town is about 65 km from the district
headquarters at <a  href="http://en.m.wikipedia.org/wiki/Karimnagar">Karimnagar,</a> at an average elevation of 264 metres (866 ft) above sea level.</p>
   
        <p>As of the 2001 Indian census, Itikial had a
population of 12,400. Males constitute 48% of
the population and females 52%. Itikial has an
average <a href="http://en.m.wikipedia.org/wiki/Literacy_rate">literacy rate</a> of 63%, higher than the national average of 59.5%. Male literacy is 75%,
and female literacy is 51%.</p>
        
           <div class="cleaner"></div>        
        </div> <!-- end of a column -->
        
       <div class="column_w210 fl vl_divider">
        
           <div class="header_01">
               Categories
            </div>
            
           <ul class="category_list">
                 <li><a href="#">Lorem ipsum dolor</a></li>
                <li><a href="#">Aenean ac lobortis felis</a></li>
                <li><a href="#">Cras eros dolor</a></li>
                <li><a href="#">Vivamus orci velit</a></li>
                <li><a href="#">Proin ultrices eros</a></li>
                <li><a href="#">Aliquam ac nisl eget</a></li>
                <li><a href="#">Praesent vehicula tellus</a></li>
                <li><a href="#">Mauris egestas nunc</a></li>
                <li><a href="#">Ut semper porta magna</a></li>
                <li><a href="#">Donec ante risus</a></li>
                <li><a href="#">Nunc bibendum neque</a></li>
          </ul>
            
        
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="margin_bottom_20 h_divider"></div>        
        <div class="margin_bottom_20"></div>
        
        <div class="column_w920">
        
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_02.jpg" alt="image" /></a>
              <p>Ever green  nature and peaceful environment  high yield crops and fields in itikyal....<a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_03.jpg" alt="image" /></a>
          <p>Load sir Venkateswara temple located in the middle of the village by join three ways at place in itikyal village. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_04.jpg" alt="image" /></a>
          <p>Proin consequat interdum mauris id auctor. In justo dolor, luctus sed tristique vel, porttitor eu enim. In molestie vehicula pretium  iaculis. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl">
               <a href="#"><img src="images/templatemo_image_05.jpg" alt="image" /></a>
          <p>Suspendisse odio erat, mattis in hend rerit id, iaculis at metus. Aliquam ligula justo, gravida sed pretium eu. <a href="#">Read more...</a></p>                
          </div>
        
            <div class="margin_bottom_15"></div>
        </div>
    
       <div class="cleaner"></div>
   </div> <!-- end of wrapper 02 -->        
    </div> <!-- end of wrapper 01 -->
    
<?php include ( "footer.php" ); ?></body>
</html>