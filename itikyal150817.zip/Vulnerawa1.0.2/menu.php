<?php
echo '<h1><a href="action.php">Login</a>
<a href="about.php">About</a></h1>'
?>