<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<meta name="generator" content="LibreOffice 5.1.6.2 (Linux)"/>
	<meta name="created" content="00:00:00"/>
	<meta name="changed" content="2017-08-15T18:11:59.680766819"/>
	<meta name="created" content="00:00:00">
	<meta name="changed" content="2017-08-15T18:06:50.300403361">
</head>
<body lang="en-IN" bgcolor="#ffc0cb" dir="ltr">
<p align="center" style="margin-bottom: 0cm">Login Form</p>
<form action="process.php" method="post">
	<center>
		<table cellpadding="2" cellspacing="10" bgcolor="#add8e6">
			<tr>
				<td style="border-top: 1.50pt double #808080; border-bottom: 1px double #808080; border-left: 1.50pt double #808080; border-right: none; padding-top: 0.05cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0cm">
					<p>Username</p>
				</td>
				<td style="border-top: 1.50pt double #808080; border-bottom: 1px double #808080; border-left: 1px double #808080; border-right: none; padding-top: 0.05cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0cm">
					<p><a name="myusername"></a><input type="text" name="username"  size="20" style="width: 4.45cm; height: 0.77cm"></p>
				</td>
				<td valign="top" style="border-top: 1.50pt double #808080; border-bottom: 1px double #808080; border-left: 1px double #808080; border-right: 1.50pt double #808080; padding: 0.05cm"></td>
			</tr>
			<tr>
				<td style="border-top: none; border-bottom: 1px double #808080; border-left: 1.50pt double #808080; border-right: none; padding-top: 0cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0cm">
					<p>Password</p>
				</td>
				<td style="border-top: none; border-bottom: 1px double #808080; border-left: 1px double #808080; border-right: none; padding-top: 0cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0cm">
					<p style="margin-bottom: 0cm"><a name="mypassword"></a><input type="password" name="password"  size="20" style="width: 4.45cm; height: 0.77cm; font-family: 'Liberation Mono', monospace; font-size: 10pt">
										</p>
					<p><br/>

					</p>
				</td>
				<td valign="top" style="border-top: none; border-bottom: 1px double #808080; border-left: 1px double #808080; border-right: 1.50pt double #808080; padding-top: 0cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0.05cm"></td>
			</tr>
			<tr>
				<td style="border-top: none; border-bottom: 1.50pt double #808080; border-left: 1.50pt double #808080; border-right: none; padding-top: 0cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0cm"></td>
				<td style="border-top: none; border-bottom: 1.50pt double #808080; border-left: 1px double #808080; border-right: none; padding-top: 0cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0cm">
					<div align="center">
						<p><input type="submit" name="submit" value="Submit"  style="width: 4.27cm; height: 0.82cm"></p>
					</div>
				</td>
				<td style="border-top: none; border-bottom: 1.50pt double #808080; border-left: 1px double #808080; border-right: 1.50pt double #808080; padding-top: 0cm; padding-bottom: 0.05cm; padding-left: 0.05cm; padding-right: 0.05cm"></td>
			</tr>
		</table>
	</center>
</form>
<p><br/>
<br/>

</p>
</body>
</html>