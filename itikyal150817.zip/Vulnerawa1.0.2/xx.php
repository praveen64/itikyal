
<!DOCTYPE html>
<html> <body><?php
if($_COOKIE)
{   print_r($_COOKIE);
//print all cookie
}else {    
echo "COOKIE is not set"; 
?></body></html>