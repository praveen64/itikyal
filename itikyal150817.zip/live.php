<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="Js/poll.js">
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>:::::WELCOME..! TO OUR ITIKYAL VILLAGE WEBSITE::::::  ::::WE HAPPY TO HELP YOU :::: </title>
<meta name="keywords" content="Lin Photo, free website template, XHTML CSS layout" />
<meta name="description" content="Lin Photo, free website template, free XHTML CSS layout provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>
</head>
<body>
<?php INCLUDE ('header.php'); ?>

   <div id="templatemo_content_wrapper">
       <div id="templatemo_content">
    
       <div class="column_w210 fl">
        
           <div class="header_01">
               Latest Blog Posts
            </div>
            
         <div class="latest_news">
              <div class="header_03">[29-OCT-2024]</div>
               <div class="header_02"><a href="#">Aenean a bibendum augue</a></div>
                
                <p>Praesent eu ligula quis nibh ullamcorper tempor non ultrices lacus.</p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[28-OCT-2024]</div>
              <div class="header_02"><a href="#">Nulla pharetra leo eget </a></div>
                <p>Vivamus condimentum justo id tortor rhoncus eu ornare sem malesuada. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[27-OCT-2024]</div>
              <div class="header_02"><a href="#">Vivamus metus justo</a></div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="rc_btn_01"><a href="#">Read All</a></div>
            
        
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="column_w430 fl vl_divider">
           
            <iframe src="https://embed.bambuser.com/channel/itikyal" width="460" height="403" frameborder="0">Your browser does not support iframes.</iframe>
            
            <div class="header_01">Live  to our Itikyal Village website!</div>
            
         
        
           <div class="cleaner"></div>        
        </div> <!-- end of a column -->
        
       <div class="column_w210 fl vl_divider">
        
           <div class="header_01">
               Categories
            </div>
            
           <ul class="category_list">
                 <li><a href="#">Lorem ipsum dolor</a></li>
                <li><a href="#">Aenean ac lobortis felis</a></li>
                <li><a href="#">Cras eros dolor</a></li>
                <li><a href="#">Vivamus orci velit</a></li>
                <li><a href="#">Proin ultrices eros</a></li>
                <li><a href="#">Aliquam ac nisl eget</a></li>
                <li><a href="#">Praesent vehicula tellus</a></li>
                <li><a href="#">Mauris egestas nunc</a></li>
                <li><a href="#">Ut semper porta magna</a></li>
                <li><a href="#">Donec ante risus</a></li>
                <li><a href="#">Nunc bibendum neque</a></li>
          </ul>
            
        
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="margin_bottom_20 h_divider"></div>        
        <div class="margin_bottom_20"></div>
        
        <div class="column_w920">
        
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_02.jpg" alt="image" /></a>
              <p>Nam sit amet justo vel libero tincidunt dignissim. Cras magna velit, pellentesque mattis, faucibus vitae, feugiat vitae. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_03.jpg" alt="image" /></a>
          <p>Pellentesque tortor metus, gravida ut aliquet non, iaculis nec nisi. Null am ornare, mauris vitae vehicula veh icula. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_04.jpg" alt="image" /></a>
          <p>Proin consequat interdum mauris id auctor. In justo dolor, luctus sed tristique vel, porttitor eu enim. In molestie vehicula pretium  iaculis. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl">
               <a href="#"><img src="images/templatemo_image_05.jpg" alt="image" /></a>
          <p>Suspendisse odio erat, mattis in hend rerit id, iaculis at metus. Aliquam ligula justo, gravida sed pretium eu. <a href="#">Read more...</a></p>                
          </div>
        
            <div class="margin_bottom_15"></div>
        </div>
    
       <div class="cleaner"></div>
   </div> <!-- end of wrapper 02 -->        
    </div> <!-- end of wrapper 01 -->
   
<?php INCLUDE ('footer.php'); ?></body>
</html>