    <div id="templatemo_footer">
    
    <ul class="footer_list">
            <li><a href="index.php" >Home</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            <li><a href="login.php">Live</a></li>
            <li><a href="notifications.php">Notifications</a></li>
            <li><a href="members.php">Members</a></li>
            <li class="last"><a href="contactus.php">Sign up</a></li>
        </ul> 
        
        <div class="margin_bottom_10"></div>
        
        &copy; Copyright -   <?php echo date('Y') ; ?> <br> All rights reserved.  <a href="#" target="_parent">praveen gadikoppula</a>
        
        <div class="margin_bottom_10"></div>

<div id="poll">

<h3>::: Do you like praveen website :::</h3><form>
Yes:
<input type="radio" name="vote" value="0" onclick="getVote(this.value)">
<br>No:
<input type="radio" name="vote" value="1" onclick="getVote(this.value)">
</form><script type="text/javascript" language="javascript">
      var aax_size='728x90';
      var aax_pubname = 'praveenamz-21';
      var aax_src='302';
    </script>
    <script type="text/javascript" language="javascript" src="http://c.amazon-adsystem.com/aax2/assoc.js"></script>
</div>
      </div> <!-- end of footer -->
</div> <!-- end of container -->
<div align=center>This website Designed By <a href='http://www.facebook.com/praveen646464'>Praveen Gadikoppula</a></div>
