<?php
$con=mysqli_connect("sql313.cuccfree.com","cucch_14999267","p1p2p364","cucch_14999267_itikyal");
if (mysqli_connect_errno())
{ echo "praveen i am sorry mysql not connect:".mysqli_connect_error();
} 
?>