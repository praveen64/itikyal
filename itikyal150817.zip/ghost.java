class sample{

public static void main(String args[])
{ int i;
  for(i=0;i<=50;i++)
   System.out.println("ubuntu java is running line"+i);

}
}
