
<div id="templatemo_container">
   <div id="templatemo_banner">
       <div id="logo"></div>  

        <div id="search_section">
            <form action="#" method="get">
                <input type="text" value="Enter keyword here..." name="q" size="10" id="searchfield" title="searchfield" onfocus="clearText(this)" onblur="clearText(this)" />
              <input type="submit" name="Search" value="Search" alt="Search" id="searchbutton" title="Search" />
            </form>
        </div> 

    </div> <!-- end of banner -->
    
    <div id="templatemo_menu">
        <ul>
            <li><a href="index.html" class="current"><span></span>Home</a></li>
            <li><a href="Gallery.html"><span></span>Gallery</a></li>
            <li><a href="login.html"><span></span>Live</a></li>
            <li><a href="Notifications.html"><span></span>Notifications</a></li>            
            <li><a href="history.html"><span></span>History</a></li>
            <li><a href="contact us.html"><span></span>Contact Us</a></li>
        </ul>   
   </div> <!-- end of menu -->