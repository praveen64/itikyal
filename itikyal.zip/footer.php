
    <div id="templatemo_footer">
    
    <ul class="footer_list">
            <li><a href="#" class="current">Home</a></li>
            <li><a href="Gallery.html">Gallery</a></li>
            <li><a href="login.html">Live</a></li>
            <li><a href="Notifications.html">Notifications</a></li>
            <li><a href="History.html">History</a></li>
            <li class="last"><a href="contact us.html">Contact Us</a></li>
        </ul> 
        
        <div class="margin_bottom_10"></div>
        
        Copyright (c) 2014 by <a href="#" target="_parent">Praveen Creations</a>
        
        <div class="margin_bottom_10"></div>
        
    
<div id="poll">
<h3>::: Do you like itikyal website :::</h3>
<form>
Yes:
<input type="radio" name="vote" value="0" onclick="getVote(this.value)">
<br>No:
<input type="radio" name="vote" value="1" onclick="getVote(this.value)">
</form>
</div>
      </div> <!-- end of footer -->
</div> <!-- end of container -->
<div align=center>This website Designed By <a href='http://www.facebook.com/praveen646464'>Praveen Gadikoppula</a></div>

<!--  Free CSS Template is provided by www.TemplateMo.com  -->
<div align=center>This website Designed By <a href='http://www.facebook.com/praveen646464'>Praveen Gadikoppula</a></div>