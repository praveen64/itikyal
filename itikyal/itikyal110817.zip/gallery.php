<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link href="themes/5/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/5/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
<script src="Js/poll.js">
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Iitkyal gallery</title>
<meta name="itikyal gallery ,itikyal photos, itikyal words most beauty " />
<meta name="description" content="itikyal village photos and itikyal gallery the beauty of village brought you by praveen gadikoppula" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>
</head>
<body>
<?php include_once("analyticstracking.php") ?>
<?php INCLUDE ('header.php'); ?>

    <div id="sliderFrame">
        <div id="ribbon"></div>
        <div id="slider">
            <a href="http://www.menucool.com/">
                <img src="images1/image-slider-1.jpg" alt="::::Sri Venkataswara Temple Itikya::::" />
            </a>
            <a class="lazyImage" href="images1/image-slider-2.jpg" title="Customizable Transition Effects">Customizable Transition Effects</a>
            <a href="http://www.menucool.com/javascript-image-slider">
                <b data-src="images1/image-slider-3.jpg" data-alt="#htmlcaption3">Image Slider</b>
            </a>
            <a class="lazyImage" href="images1/image-slider-4.jpg" title="Pure Javascript. No jQuery. No flash.">Plain Javascript Slider</a>
            <a class="lazyImage" href="images1/image-slider-5.jpg" title="#htmlcaption5">Lazy Loading Image</a>
            <a class="lazyImage" href="images1/image-slider-1.jpg" title="Light weight Image Slider">Light weight Image Slider</a>
            <a class="lazyImage" href="images1/image-slider-2.jpg" title="Fine tuned. Sleek & Smooth">Fine tuned. Sleek & Smooth</a>
            <a class="lazyImage" href="images1/image-slider-3.jpg" title="Easy-to-Use Slider">Easy-to-Use Slider</a>
        </div>
        <div style="display: none;">
            <div id="htmlcaption3">
                <em>HTML</em> caption. Back to <a href="http://www.menucool.com/">Menucool</a>.
            </div>
            <div id="htmlcaption5">
                Smart Lazy Loading Image
            </div>
        </div>
                
        <!--thumbnails-->
        <div id="thumbs">
            <div class="thumb"><img src="images1/thumb1.jpg" /></div>
            <div class="thumb"><img src="images1/thumb2.jpg" /></div>
            <div class="thumb"><img src="images1/thumb3.jpg" /></div>
            <div class="thumb"><img src="images1/thumb4.jpg" /></div>
            <div class="thumb"><img src="images1/thumb5.jpg" /></div>
            <div class="thumb"><img src="images1/thumb1.jpg" /></div>
            <div class="thumb"><img src="images1/thumb2.jpg" /></div>
            <div class="thumb"><img src="images1/thumb3.jpg" /></div></div></div>
        
    
<?php INCLUDE ('footer.php'); ?></body>
</html>