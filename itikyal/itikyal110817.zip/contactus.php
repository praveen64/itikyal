<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="table.css" type="text/css"/>   
<script src="Js/poll.js">
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sign up of itikyal members online</title>
<meta name="keywords" content="itikyal signup,Itikyal registration,signup itikyal,create account itikyal,join to itikyal,add itikyal,itikyal,praveen gadikoppula,Itikyal Join" />
<meta name="description" content="Join in our itikyal members list and be online to every one site" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>
</head>
<body>
<?php INCLUDE ('header.php'); ?>
   <div id="templatemo_content_wrapper">
       <div id="templatemo_content">
    
       <div class="column_w210 fl">
        
           <div class="header_01">
               Latest Blog Posts
            </div>
            
         <div class="latest_news">
              <div class="header_03">[29-OCT-2024]</div>
               <div class="header_02"><a href="#">Aenean a bibendum augue</a></div>
                
                <p>Praesent eu ligula quis nibh ullamcorper tempor non ultrices lacus.</p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[13-JAN-2015]</div>
              <div class="header_02"><a href="#">Nulla pharetra leo eget </a></div>
                <p>Vivamus condimentum justo id tortor rhoncus eu ornare sem malesuada. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[27-OCT-2024]</div>
              <div class="header_02"><a href="#">Vivamus metus justo</a></div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="rc_btn_01"><a href="#">Read All</a></div>
            
        <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=tf_til&ad_type=product_link&tracking_id=praveenamz-21&marketplace=amazon&region=IN&placement=B00WGCWOPY&asins=B00WGCWOPY&linkId=72575302b1e165f021c9a19a248ce7fd&show_border=false&link_opens_in_new_window=false&price_color=333333&title_color=0066c0&bg_color=ffffff">
    </iframe>
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="column_w430 fl vl_divider">
           
    <center><div class="CSS_Table_Example" style="width:350px;"><table>
<form method="post" action="signup.php"><tr><td>Details From</td></tr><tr><td>
First Name:<input type="text"  name="firstname"></td></tr><tr><td>
Last Name:<input type="text" name="lastname"></td></tr><tr><td>Mobile:<input type="text" name="mobile"></td></tr><tr><td>
Gender: <input type="radio" name="gender" value="Male">Male
<input type="radio" name="gender" value="Female">Female</tb></tr><tr><td>Email:<input type="email" name="email"></td></tr><tr><td>
Address:<textarea rows="2" cols="15" name="address"></textarea></td></tr><tr><td>
Education:<select name="education"> 
<option value="INTER">Inter</option>
  <option value="DEGREE">Degree</option>
  <option value="SSC">SSC</option>
  <option value="PHD">PHD</option>
<option value="BTECH">BTECH</option>
  <option value="BPHARM">BPHARM</option>
  <option value="MBA">MBA</option>
  <option value="MCA">MCA</option>
  <option value="OTHER">Other</option>
</select></td></tr><tr><td>Occupation:<input type="text" name="occupation"></td></tr><tr><td>Age:<input type="text" name="age"></td></tr><tr><td>
<input type="checkbox" name="Agree" value="ok">I Agree terms and conditions</td></tr><tr><td><center><input type="submit"></center></td></tr>
</table></form></div>
<script type="text/javascript">amzn_assoc_ad_type ="responsive_search_widget"; amzn_assoc_tracking_id ="praveenamz-21"; amzn_assoc_marketplace ="amazon"; amzn_assoc_region ="IN"; amzn_assoc_placement =""; amzn_assoc_search_type = "search_widget";amzn_assoc_width ="auto"; amzn_assoc_height ="auto"; amzn_assoc_default_search_category =""; amzn_assoc_default_search_key ="Agriculture";amzn_assoc_theme ="light"; amzn_assoc_bg_color ="FFFFFF"; </script><script src="//z-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1&Marketplace=IN"></script>
</center>

         
        
           <div class="cleaner"></div>        
        </div> <!-- end of a column -->
        
       <div class="column_w210 fl vl_divider">
        
           <div class="header_01">
               Categories
            </div>
            
           <ul class="category_list">
                 <li><a href="#">Lorem ipsum dolor</a></li>
                <li><a href="#">Aenean ac lobortis felis</a></li>
                <li><a href="#">Cras eros dolor</a></li>
                <li><a href="#">Vivamus orci velit</a></li>
                <li><a href="#">Proin ultrices eros</a></li>
                <li><a href="#">Aliquam ac nisl eget</a></li>
                <li><a href="#">Praesent vehicula tellus</a></li>
                <li><a href="#">Mauris egestas nunc</a></li>
                <li><a href="#">Ut semper porta magna</a></li>
                <li><a href="#">Donec ante risus</a></li>
                <li><a href="#">Nunc bibendum neque</a></li>
          </ul>
            
        <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=tf_til&ad_type=product_link&tracking_id=praveenamz-21&marketplace=amazon&region=IN&placement=B01J40F2AY&asins=B01J40F2AY&linkId=c45698242aeecc2c01aedd5328f385dd&show_border=false&link_opens_in_new_window=false&price_color=333333&title_color=0066c0&bg_color=ffffff">
    </iframe>
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="margin_bottom_20 h_divider"></div>        
        <div class="margin_bottom_20"></div>
        
        <div class="column_w920">
        
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_02.jpg" alt="image" /></a>
              <p>Nam sit amet justo vel libero tincidunt dignissim. Cras magna velit, pellentesque mattis, faucibus vitae, feugiat vitae. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_03.jpg" alt="image" /></a>
          <p>Pellentesque tortor metus, gravida ut aliquet non, iaculis nec nisi. Null am ornare, mauris vitae vehicula veh icula. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_04.jpg" alt="image" /></a>
          <p>Proin consequat interdum mauris id auctor. In justo dolor, luctus sed tristique vel, porttitor eu enim. In molestie vehicula pretium  iaculis. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl">
               <a href="#"><img src="images/templatemo_image_05.jpg" alt="image" /></a>
          <p>Suspendisse odio erat, mattis in hend rerit id, iaculis at metus. Aliquam ligula justo, gravida sed pretium eu. <a href="#">Read more...</a></p>                
          </div>
        
            <div class="margin_bottom_15"></div>
        </div>
    
       <div class="cleaner"></div>
   </div> <!-- end of wrapper 02 -->        
    </div> <!-- end of wrapper 01 -->
    
<?php INCLUDE ('footer.php'); ?></body>
</html>