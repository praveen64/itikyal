
<html>
<head>
</head>
<body bgcolor="pink">


<center>


<form action="process.php" method="post">
<table border="2" cellspacing="10" bgcolor="lightblue">
<tr>Login Form </tr>
<tr>
<td>Username</td>
<td><input name="username" type="text" id="myusername"></td>
</tr>
<tr>
<td>Password</td>
<td><input name="password" type="password" id="mypassword"> </td>
</tr>
<center>
<tr>
<td>
</td>
<td>
<center><input type="Submit" value="Submit" name="submit" ></center>
</td>
<td>
</tr>
</center>
</form>
</center>
</body>

</html>
