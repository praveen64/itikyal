<html>
<head bg color="pink">
<title>shunya.com</title>
<center>  
<form method="get" action="db.php">
<input type="submit" value="CREATE DATABASE">

<h1><center>Welcome to Vulnerawa</center></h1>
</head>
<body bgcolor="pink">

<div class="leftmenu">
<?php include 'menu.php';?>
</div>



</table>
<p align="center">Vulnerawa is a simple vulnerable web application developed by Kanishka10.</p>
<p align="center">At present,it features only SQL Injection. </p>
<p align="center">Other vulnerabilites will soon be added in later versions.</p>
<center>


</center>
</form>
</p>
<marquee behavior="bounce"><blink>We are now ISO 27001 Certified</blink></marquee>
</body>


  

</html>