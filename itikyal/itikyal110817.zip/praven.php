
<!DOCTYPE html>
<html>
<body>

<?php 
for($x = 50; $x<= 90; $x++) {
echo"$x";
echo " <img src='http://results.cgg.gov.in/scannedPhotos/28139/002/1950_photo.jpg'>";
echo"http://results.cgg.gov.in/scannedPhotos/28139/002/19$x_photo.jpg"; }
?>

</body>
</html>