<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <link rel="stylesheet" href="table.css" type="text/css"/>   
<script src="Js/poll.js">
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>:::::WELCOME..! TO OUR ITIKYAL VILLAGE WEBSITE::::::  ::::WE HAPPY TO HELP YOU :::: </title>
<meta name="keywords" content="Lin Photo, free website template, XHTML CSS layout" />
<meta name="description" content="Lin Photo, free website template, free XHTML CSS layout provided by templatemo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>
</head>
<body>
<?php INCLUDE ('header.php'); ?>

   <div id="templatemo_content_wrapper">
       <div id="templatemo_content">
    
       <div class="column_w210 fl">
        
           <div class="header_01">
               Latest Blog Posts
            </div>
            
         <div class="latest_news">
              <div class="header_03">[29-OCT-2024]</div>
               <div class="header_02"><a href="#">Aenean a bibendum augue</a></div>
                
                <p>Praesent eu ligula quis nibh ullamcorper tempor non ultrices lacus.</p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[28-OCT-2024]</div>
              <div class="header_02"><a href="#">Nulla pharetra leo eget </a></div>
                <p>Vivamus condimentum justo id tortor rhoncus eu ornare sem malesuada. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="latest_news">
                <div class="header_03">[27-OCT-2024]</div>
              <div class="header_02"><a href="#">Vivamus metus justo</a></div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
         </div>
                        
            <div class="margin_bottom_10"></div>
            
            <div class="rc_btn_01"><a href="#">Read All</a></div>
            
        
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="column_w430 fl vl_divider">
           

<script language="javascript">
<!--//
/*This Script allows people to enter by using a form that asks for a
UserID and Password*/
function pasuser(form) {
if (form.id.value=="itikyal") { 
if (form.pass.value=="12345") {              
location="live.php" 
} else {
alert("Invalid Password")
}
} else {  alert("Invalid UserID")
}
}
//-->
</script>

<center>
      <div class="CSS_Table_Example">
<table cellpadding="12" border="1" style="border: 0px dashed #FF0000">
<tr><td colspan="2" bordercolor="#FFFF00" style="border: 1px solid #FF0000"><center><h1><i><b>
 <font size="3">Login to watch live</font></b></i></h1></center></td></tr>
<tr><td height="30" bordercolor="#FFFF00" style="border: 1px solid #FF0000"><h1><i><b>
 <font size="3">UserID:</font></b></i></h1></td>
 <td height="64" bordercolor="#FFFF00" style="border: 1px solid #FF0000"><form name="login"><input
name="id" type="text"></td></tr>
<tr><td bordercolor="#FFFF00" style="border: 1px solid #FF0000"><h1><i><b>
 <font size="3">Password:</font></b></i></h1></td>
 <td bordercolor="#FFFF00" style="border: 1px solid #FF0000"><input name="pass"
type="password"></td></tr>
<tr><td bordercolor="#FFFF00" style="border: 1px solid #FF0000" height="51"><center><input type="button" value="Login"
onClick="pasuser(this.form)"></center></td>
 <td bordercolor="#FFFF00" style="border: 1px solid #FF0000" height="51"><center><input
type="Reset"></form></td></tr></table></div></center><img src="images/Flag.png" width="20" heigth="20" alt="NOTE"><P>NOTE: <font face="Times New Roman" size="3">Please use the below username and password to login</font></p>
<center><Font color="orange" size="4" face="Garamond">Username :</font><font color="green" size="4"><U>Itikyal</U></font><br><Font color="orange" size="4" face="Garamond">Password  :</font><font color="green" size="4"><U>12345</U></font>
        
           <div class="cleaner"></div>        
        </div> <!-- end of a column -->
        
       <div class="column_w210 fl vl_divider">
        
           <div class="header_01">
               Categories
            </div>
            
           <ul class="category_list">
                 <li><a href="#">Lorem ipsum dolor</a></li>
                <li><a href="#">Aenean ac lobortis felis</a></li>
                <li><a href="#">Cras eros dolor</a></li>
                <li><a href="#">Vivamus orci velit</a></li>
                <li><a href="#">Proin ultrices eros</a></li>
                <li><a href="#">Aliquam ac nisl eget</a></li>
                <li><a href="#">Praesent vehicula tellus</a></li>
                <li><a href="#">Mauris egestas nunc</a></li>
                <li><a href="#">Ut semper porta magna</a></li>
                <li><a href="#">Donec ante risus</a></li>
                <li><a href="#">Nunc bibendum neque</a></li>
          </ul>
            
        
           <div class="cleaner"></div>
        </div> <!-- end of a column -->
        
        <div class="margin_bottom_20 h_divider"></div>        
        <div class="margin_bottom_20"></div>
        
        <div class="column_w920">
        
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_02.jpg" alt="image" /></a>
              <p>Nam sit amet justo vel libero tincidunt dignissim. Cras magna velit, pellentesque mattis, faucibus vitae, feugiat vitae. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_03.jpg" alt="image" /></a>
          <p>Pellentesque tortor metus, gravida ut aliquet non, iaculis nec nisi. Null am ornare, mauris vitae vehicula veh icula. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl margin_right_40">
               <a href="#"><img src="images/templatemo_image_04.jpg" alt="image" /></a>
          <p>Proin consequat interdum mauris id auctor. In justo dolor, luctus sed tristique vel, porttitor eu enim. In molestie vehicula pretium  iaculis. <a href="#">Read more...</a></p>                
          </div>
            
      <div class="column_w190 fl">
               <a href="#"><img src="images/templatemo_image_05.jpg" alt="image" /></a>
          <p>Suspendisse odio erat, mattis in hend rerit id, iaculis at metus. Aliquam ligula justo, gravida sed pretium eu. <a href="#">Read more...</a></p>                
          </div>
        
            <div class="margin_bottom_15"></div>
        </div>
    
       <div class="cleaner"></div>
   </div> <!-- end of wrapper 02 -->        
    </div> <!-- end of wrapper 01 -->
 <?php INCLUDE ('footer.php'); ?>   </body>
</html>